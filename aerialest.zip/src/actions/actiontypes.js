export const INITIALIZED = 'kreu.app.INITIALIZED';
export const ROOT_CHANGED = 'kreu.app.ROOT_CHANGED';
